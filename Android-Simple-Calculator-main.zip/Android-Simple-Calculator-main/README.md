# Android Simple Calculator
A simple calculator for android

# Preview
![](https://github.com/coderHM79/MHM-Simple-Calculator/blob/main/Preview.gif)
